Overall Coverage Statistics
-----------------------------------

bash-2.05b$ gcov sch_app.c
100.00% of 342 source lines executed in file ../src/sch_app.c
Creating sch_app.c.gcov.

bash-2.05b$ gcov sch_cmds.c
100.00% of 250 source lines executed in file ../src/sch_cmds.c
Creating sch_cmds.c.gcov.

bash-2.05b$ gcov sch_custom.c
100.00% of 91 source lines executed in file ../src/sch_custom.c
Creating sch_custom.c.gcov.

bash-2.05b$ gcov sch_api.c
100.00% of 9 source lines executed in file ../src/sch_api.c
Creating sch_api.c.gcov.

---------------------------------------------------------------------------------------
